##########################################
# PYQT5, QT designer를 활용한 개인 프로젝트
# 2024-05-03 
##########################################

##########################################
# 라이브러리 설치
import sys
from PyQt5.QtWidgets import * # QtWidgets 윈도우 core 
from PyQt5 import uic
from PyQt5.QtCore import *
##########################################



##########################################
# ui 파일 불러오기
LogInPage = uic.loadUiType(r"C:\AI_lecture\pyqt_personal_project\LogIn.ui")[0]
MainPage = uic.loadUiType(r"C:\AI_lecture\pyqt_personal_project\MainPage.ui")[0]
GamePage = uic.loadUiType(r"C:\AI_lecture\pyqt_personal_project\game1.ui")[0]

# 이미지 resource py파일 생성코드 -> 터미널에 코드 넣어줘서 파일 만들어야함
# pyrcc5 resource.qrc -o resource_rc.py
##############################################



###########################################
# 로그인화면
class MyWindow(QMainWindow, LogInPage):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btn.clicked.connect(self.btn_clicked)
        

# 로그인 버튼 클릭하면 메인 페이지로 넘어가기
    def btn_clicked(self):
        self.hide()
        self.main = MyWindow2()
        self.main.show()
#############################################




#############################################
# 메인화면
class MyWindow2(QMainWindow, MainPage):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.widget_3.setVisible(False)  # widget_3를 숨깁니다.
        self.widget_10.setVisible(False)  # widget_10를 숨깁니다.
        self.pushButton.clicked.connect(self.pushButtonClicked) # 왼쪽 슬라이드바 버튼
        self.pushButton_4.clicked.connect(self.pushButton4Clicked) # 프로필 버튼
        self.pushButton_13.clicked.connect(self.pushButton13Clicked) # 발로란트 버튼

        self.short = True
        self.profile = True

    def pushButton13Clicked(self):
        self.hide()
        self.main = GameWindow()
        self.main.show()

    def pushButtonClicked(self):
        if self.short == True:
            self.widget_3.setVisible(True)
            self.widget.setVisible(False)
            self.short = False

        else:
            self.widget_3.setVisible(False)
            self.widget.setVisible(True)
            self.short = True

    def pushButton4Clicked(self):
        if self.profile == True:
            self.widget_10.setVisible(True)
            self.profile = False

        else:
            self.widget_10.setVisible(False)
            self.profile = True

#############################################



#############################################
# 게임화면
class GameWindow(QMainWindow, GamePage):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.widget_3.setVisible(False)  # widget_3를 숨깁니다.
        self.widget_10.setVisible(False)  # widget_10를 숨깁니다.
        self.pushButton.clicked.connect(self.pushButtonClicked) # 왼쪽 슬라이드 버튼
        self.pushButton_4.clicked.connect(self.pushButton4Clicked) # 프로필 버튼
        self.pushButton_2.clicked.connect(self.pushButton2Clicked) # 뒤로가기 버튼

        self.short = True
        self.profile = True

    def pushButton2Clicked(self):
        self.hide()
        self.main = MyWindow2()
        self.main.show()


    def pushButtonClicked(self):
        if self.short == True:
            self.widget_3.setVisible(True)
            self.widget.setVisible(False)
            self.short = False

        else:
            self.widget_3.setVisible(False)
            self.widget.setVisible(True)
            self.short = True

    def pushButton4Clicked(self):
        if self.profile == True:
            self.widget_10.setVisible(True)
            self.profile = False

        else:
            self.widget_10.setVisible(False)
            self.profile = True

#############################################


app = QApplication(sys.argv)
window = MyWindow()
window.show()
app.exec_()
